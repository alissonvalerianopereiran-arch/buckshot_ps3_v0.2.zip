/* Teste da logica no PC:  gcc -std=c99 -Iinclude pc_test/main_pc.c source/game.c -o br_pc */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static void show(Game *g)
{
    int i;
    printf("\n== RODADA %d | VOCE %d/%d | DEALER %d/%d | restam: %d reais, %d vazios ==\n",
           g->round, g->hp[PLAYER], g->maxhp, g->hp[DEALER], g->maxhp,
           g->live_left, g->blank_left);
    printf("Seus itens: ");
    for (i = 0; i < MAX_ITEMS; i++)
        if (g->items[PLAYER][i]) printf("[%d]%s ", i, item_name(g->items[PLAYER][i]));
    printf("\nItens dealer: ");
    for (i = 0; i < MAX_ITEMS; i++)
        if (g->items[DEALER][i]) printf("%s ", item_name(g->items[DEALER][i]));
    printf("\n");
}

int main(int argc, char **argv)
{
    Game g;
    int i;
    char line[32];

    game_init(&g, (argc > 1) ? (uint32_t)atoi(argv[1]) : (uint32_t)time(NULL));

    while (g.state == GS_PLAYING) {
        if (g.turn == DEALER) {
            dealer_act(&g);
        } else {
            printf("\n--- log ---\n");
            for (i = 0; i < g.log_n; i++) printf("  %s\n", g.log[i]);
            show(&g);
            printf("(d)atirar no dealer, (s)atirar em si, 0-7 usar item, (q)uit > ");
            if (!fgets(line, sizeof line, stdin)) return 0;
            if (line[0] == 'q') return 0;
            if (line[0] == 'd') game_shoot(&g, PLAYER, DEALER);
            else if (line[0] == 's') game_shoot(&g, PLAYER, PLAYER);
            else if (line[0] >= '0' && line[0] <= '7') game_use_item(&g, PLAYER, line[0] - '0');
        }
    }
    for (i = 0; i < g.log_n; i++) printf("  %s\n", g.log[i]);
    printf(g.state == GS_WIN ? "\n*** VITORIA ***\n" : "\n*** DERROTA ***\n");
    return 0;
}
