/* Gera WAVs de preview:  gcc -std=c99 -Iinclude pc_test/sfx_dump.c source/sfx.c -lm -o sfx_dump && ./sfx_dump out/ */
#include "sfx.h"
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <stdlib.h>

static void wr32(FILE *f, uint32_t v){ fputc(v&255,f);fputc((v>>8)&255,f);fputc((v>>16)&255,f);fputc((v>>24)&255,f); }
static void wr16(FILE *f, uint16_t v){ fputc(v&255,f);fputc((v>>8)&255,f); }

int main(int argc, char **argv)
{
    const char *dir = argc > 1 ? argv[1] : ".";
    int id, i, n;
    sfx_init();
    for (id = 0; id < SFX_COUNT; id++) {
        const short *d = sfx_data(id, &n);
        char path[256]; FILE *f; int peak = 0;
        for (i = 0; i < n; i++) { int a = abs(d[i]); if (a > peak) peak = a; }
        snprintf(path, sizeof path, "%s/%02d_%s.wav", dir, id, sfx_name(id));
        f = fopen(path, "wb"); if (!f) { perror(path); return 1; }
        fwrite("RIFF",1,4,f); wr32(f, 36 + n*2); fwrite("WAVEfmt ",1,8,f);
        wr32(f,16); wr16(f,1); wr16(f,1); wr32(f,SFX_RATE); wr32(f,SFX_RATE*2); wr16(f,2); wr16(f,16);
        fwrite("data",1,4,f); wr32(f, n*2); fwrite(d,2,n,f); fclose(f);
        printf("%-10s %5.2fs  pico=%.2f\n", sfx_name(id), (double)n/SFX_RATE, peak/32767.0);
    }
    return 0;
}
