/* Buckshot Roulette - recriacao nao oficial, logica portavel (C99).
 * Nao depende de nada de PS3/Xbox: compila em PC, PS3 (PSL1GHT), 360 (libxenon). */
#ifndef BR_GAME_H
#define BR_GAME_H

#include <stdint.h>

#define MAX_SHELLS   8
#define MAX_ITEMS    8
#define LOG_LINES    8
#define LOG_LEN      64

enum { PLAYER = 0, DEALER = 1 };

enum {
    ITEM_NONE = 0,
    ITEM_LUPA,      /* mostra o cartucho atual   */
    ITEM_CERVEJA,   /* ejeta o cartucho atual    */
    ITEM_CIGARRO,   /* +1 vida                   */
    ITEM_SERRA,     /* proximo tiro = 2 de dano  */
    ITEM_ALGEMAS,   /* oponente perde a vez      */
    ITEM_COUNT
};

enum { GS_PLAYING = 0, GS_WIN, GS_LOSE };

/* Eventos para a camada de som/UI (o jogo so os enfileira) */
#define MAX_EVENTS 24
enum {
    EV_NONE = 0,
    EV_BLAST,            /* tiro real            */
    EV_BLANK,            /* tiro vazio (clique)  */
    EV_RACK,             /* proximo cartucho     */
    EV_RELOAD,           /* nova carga           */
    EV_HURT,             /* jogador levou dano   */
    EV_ITEM_BASE = 16,   /* EV_ITEM_BASE + ITEM_x */
    EV_ROUND = 32,
    EV_WIN,
    EV_LOSE
};

typedef struct {
    int      round;                 /* 1..3 */
    int      hp[2];
    int      maxhp;
    int      items[2][MAX_ITEMS];
    int      shells[MAX_SHELLS];    /* 1 = real, 0 = vazio */
    int      n_shells, pos;
    int      live_left, blank_left; /* publico: os dois sabem */
    int      turn;
    int      sawed;
    int      cuffed[2];
    int      peek;                  /* -1 desconhecido, 0 vazio, 1 real (cartucho atual) */
    int      state;
    uint32_t rng;
    char     log[LOG_LINES][LOG_LEN];
    int      log_n;
    uint8_t  ev[MAX_EVENTS];        /* quem le deve zerar ev_n */
    int      ev_n;
} Game;

void game_init(Game *g, uint32_t seed);

/* Acoes. 'who' = PLAYER ou DEALER. Retornam 1 se a acao foi valida. */
int  game_shoot(Game *g, int who, int target);
int  game_use_item(Game *g, int who, int slot);

/* IA do dealer: faz UMA acao. Chame enquanto g->turn == DEALER e state == GS_PLAYING. */
void dealer_act(Game *g);

const char *item_name(int item);
int  game_rand(Game *g, int n);   /* 0..n-1 */

#endif
