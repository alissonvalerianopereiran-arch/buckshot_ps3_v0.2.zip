/* Sons sintetizados (sem arquivos de audio, sem assets do jogo original).
 * Portavel: gera PCM em memoria e mistura em float estereo. */
#ifndef BR_SFX_H
#define BR_SFX_H

#define SFX_RATE 48000

enum {
    SFX_BLAST = 0, SFX_BLANK, SFX_RACK, SFX_RELOAD, SFX_HURT,
    SFX_LUPA, SFX_BEER, SFX_CIGARRO, SFX_SERRA, SFX_ALGEMAS,
    SFX_TICK, SFX_SELECT, SFX_BACK,
    SFX_ROUND, SFX_WIN, SFX_LOSE,
    SFX_COUNT
};

void sfx_init(void);                                   /* gera todos os sons */
void sfx_play(int id, float vol, float delay_sec);     /* delay_sec: atraso ate comecar */
void sfx_start_ambience(float vol);                    /* zumbido de fundo em loop */
void sfx_mix(float *out, int frames);                  /* out: estereo intercalado */
const short *sfx_data(int id, int *n_samples);         /* p/ ferramenta de preview */
const char  *sfx_name(int id);

#endif
