#ifndef BR_AUDIO_PS3_H
#define BR_AUDIO_PS3_H
int  audio_init(void);   /* 1 = ok, 0 = falhou (jogo segue mudo) */
void audio_pump(void);   /* chamar 1x por frame */
void audio_shutdown(void);
#endif
