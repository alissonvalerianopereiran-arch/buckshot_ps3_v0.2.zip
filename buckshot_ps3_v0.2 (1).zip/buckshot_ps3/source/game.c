#include "game.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

/* ---------- utilidades ---------- */

int game_rand(Game *g, int n)
{
    /* xorshift32 */
    uint32_t x = g->rng;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    g->rng = x;
    return (int)(x % (uint32_t)n);
}

static void logf_(Game *g, const char *fmt, ...)
{
    va_list ap;
    int i;
    if (g->log_n == LOG_LINES) {
        for (i = 1; i < LOG_LINES; i++)
            memcpy(g->log[i - 1], g->log[i], LOG_LEN);
        g->log_n--;
    }
    va_start(ap, fmt);
    vsnprintf(g->log[g->log_n], LOG_LEN, fmt, ap);
    va_end(ap);
    g->log_n++;
}

const char *item_name(int item)
{
    switch (item) {
    case ITEM_LUPA:    return "LUPA";
    case ITEM_CERVEJA: return "CERVEJA";
    case ITEM_CIGARRO: return "CIGARRO";
    case ITEM_SERRA:   return "SERRA";
    case ITEM_ALGEMAS: return "ALGEMAS";
    default:           return "-";
    }
}

static void emit(Game *g, int e)
{
    if (g->ev_n < MAX_EVENTS) g->ev[g->ev_n++] = (uint8_t)e;
}

static const char *name_of(int who) { return who == PLAYER ? "VOCE" : "DEALER"; }

/* ---------- carregar a espingarda ---------- */

static void deal_items(Game *g)
{
    int per_side, who, k, slot, tries;
    if (g->round < 2) return;
    per_side = (g->round == 2) ? 2 : 3;
    for (who = 0; who < 2; who++) {
        for (k = 0; k < per_side; k++) {
            for (tries = 0; tries < 16; tries++) {
                slot = game_rand(g, MAX_ITEMS);
                if (g->items[who][slot] == ITEM_NONE) {
                    g->items[who][slot] = 1 + game_rand(g, ITEM_COUNT - 1);
                    break;
                }
            }
        }
    }
}

static void reload(Game *g)
{
    int i, j, t, live;
    g->n_shells = 2 + game_rand(g, 5);          /* 2..6 */
    live = 1 + game_rand(g, g->n_shells - 1);   /* 1..n-1: sempre ao menos 1 real e 1 vazio */
    for (i = 0; i < g->n_shells; i++) g->shells[i] = (i < live) ? 1 : 0;
    for (i = g->n_shells - 1; i > 0; i--) {     /* Fisher-Yates */
        j = game_rand(g, i + 1);
        t = g->shells[i]; g->shells[i] = g->shells[j]; g->shells[j] = t;
    }
    g->pos = 0;
    g->live_left  = live;
    g->blank_left = g->n_shells - live;
    g->peek = -1;
    g->sawed = 0;
    deal_items(g);
    emit(g, EV_RELOAD);
    logf_(g, "CARREGADA: %d REAIS, %d VAZIOS", g->live_left, g->blank_left);
}

static void start_round(Game *g)
{
    memset(g->items, 0, sizeof(g->items));
    g->cuffed[0] = g->cuffed[1] = 0;
    g->maxhp = 2 + game_rand(g, 3);             /* 2..4 */
    g->hp[0] = g->hp[1] = g->maxhp;
    g->turn = PLAYER;
    emit(g, EV_ROUND);
    logf_(g, "--- RODADA %d  (VIDA %d) ---", g->round, g->maxhp);
    reload(g);
}

void game_init(Game *g, uint32_t seed)
{
    memset(g, 0, sizeof(*g));
    g->rng = seed ? seed : 0xC0FFEEu;
    g->round = 1;
    g->state = GS_PLAYING;
    start_round(g);
}

/* ---------- fluxo ---------- */

static void after_shell_consumed(Game *g)
{
    g->peek = -1;
    if (g->pos >= g->n_shells) reload(g);
    else emit(g, EV_RACK);
}

static void check_round_end(Game *g)
{
    if (g->hp[PLAYER] <= 0) {
        g->state = GS_LOSE;
        emit(g, EV_LOSE);
        logf_(g, "VOCE MORREU.");
    } else if (g->hp[DEALER] <= 0) {
        if (g->round >= 3) {
            g->state = GS_WIN;
            emit(g, EV_WIN);
            logf_(g, "VOCE VENCEU A NOITE!");
        } else {
            logf_(g, "DEALER CAIU. PROXIMA RODADA.");
            g->round++;
            start_round(g);
        }
    }
}

int game_shoot(Game *g, int who, int target)
{
    int shell, dmg, other = 1 - who, round_before;

    if (g->state != GS_PLAYING || g->turn != who) return 0;
    round_before = g->round;

    shell = g->shells[g->pos++];
    dmg = g->sawed ? 2 : 1;
    g->sawed = 0;

    if (shell) {
        g->live_left--;
        g->hp[target] -= dmg;
        if (g->hp[target] < 0) g->hp[target] = 0;
        emit(g, EV_BLAST);
        if (target == PLAYER) emit(g, EV_HURT);
        logf_(g, "%s ATIROU EM %s: REAL! -%d", name_of(who),
              target == who ? "SI" : name_of(target), dmg);
    } else {
        g->blank_left--;
        emit(g, EV_BLANK);
        logf_(g, "%s ATIROU EM %s: VAZIO.", name_of(who),
              target == who ? "SI" : name_of(target));
    }

    after_shell_consumed(g);
    if (g->state == GS_PLAYING) check_round_end(g);
    if (g->state != GS_PLAYING || g->round != round_before) return 1;

    /* de quem e a proxima vez? */
    if (target == who && !shell) {
        /* atirou em si com vazio: joga de novo */
    } else if (g->cuffed[other]) {
        g->cuffed[other] = 0;
        logf_(g, "%s ESTA ALGEMADO: PERDE A VEZ.", name_of(other));
    } else {
        g->turn = other;
    }
    return 1;
}

int game_use_item(Game *g, int who, int slot)
{
    int it, other = 1 - who;

    if (g->state != GS_PLAYING || g->turn != who) return 0;
    if (slot < 0 || slot >= MAX_ITEMS) return 0;
    it = g->items[who][slot];
    if (it == ITEM_NONE) return 0;

    switch (it) {
    case ITEM_LUPA:
        emit(g, EV_ITEM_BASE + it);
        g->peek = g->shells[g->pos];
        logf_(g, "%s USOU LUPA.", name_of(who));
        if (who == PLAYER)
            logf_(g, "O CARTUCHO ATUAL E %s.", g->peek ? "REAL" : "VAZIO");
        break;
    case ITEM_CERVEJA: {
        int s = g->shells[g->pos++];
        emit(g, EV_ITEM_BASE + it);
        if (s) g->live_left--; else g->blank_left--;
        logf_(g, "%s BEBEU: EJETOU CARTUCHO %s.", name_of(who), s ? "REAL" : "VAZIO");
        after_shell_consumed(g);
        break;
    }
    case ITEM_CIGARRO:
        if (g->hp[who] >= g->maxhp) { logf_(g, "VIDA JA ESTA CHEIA."); return 0; }
        emit(g, EV_ITEM_BASE + it);
        g->hp[who]++;
        logf_(g, "%s FUMOU: +1 VIDA.", name_of(who));
        break;
    case ITEM_SERRA:
        if (g->sawed) { logf_(g, "JA ESTA SERRADA."); return 0; }
        g->sawed = 1;
        emit(g, EV_ITEM_BASE + it);
        logf_(g, "%s SERROU O CANO: DANO 2.", name_of(who));
        break;
    case ITEM_ALGEMAS:
        if (g->cuffed[other]) { logf_(g, "JA ESTA ALGEMADO."); return 0; }
        g->cuffed[other] = 1;
        emit(g, EV_ITEM_BASE + it);
        logf_(g, "%s ALGEMOU %s.", name_of(who), name_of(other));
        break;
    }
    g->items[who][slot] = ITEM_NONE;
    return 1;
}

/* ---------- IA do dealer ---------- */

static int find_item(Game *g, int who, int item)
{
    int i;
    for (i = 0; i < MAX_ITEMS; i++)
        if (g->items[who][i] == item) return i;
    return -1;
}

void dealer_act(Game *g)
{
    int s, remaining, known_live;

    if (g->state != GS_PLAYING || g->turn != DEALER) return;
    remaining = g->live_left + g->blank_left;

    /* cura se estiver ferido */
    if (g->hp[DEALER] < g->maxhp && (s = find_item(g, DEALER, ITEM_CIGARRO)) >= 0) {
        game_use_item(g, DEALER, s); return;
    }
    /* descobre o cartucho */
    if (g->peek < 0 && remaining > 1 && g->live_left > 0 && g->blank_left > 0 &&
        (s = find_item(g, DEALER, ITEM_LUPA)) >= 0) {
        game_use_item(g, DEALER, s); return;
    }
    /* algemas */
    if (!g->cuffed[PLAYER] && (s = find_item(g, DEALER, ITEM_ALGEMAS)) >= 0) {
        game_use_item(g, DEALER, s); return;
    }
    /* cartucho desconhecido e 50/50: cerveja ajuda */
    if (g->peek < 0 && g->live_left == g->blank_left &&
        (s = find_item(g, DEALER, ITEM_CERVEJA)) >= 0) {
        game_use_item(g, DEALER, s); return;
    }

    /* o que o dealer sabe sobre o cartucho atual */
    if (g->peek >= 0)                known_live = g->peek;
    else if (g->live_left == 0)      known_live = 0;
    else if (g->blank_left == 0)     known_live = 1;
    else                             known_live = -1;

    if (known_live == 1) {
        if (!g->sawed && (s = find_item(g, DEALER, ITEM_SERRA)) >= 0) {
            game_use_item(g, DEALER, s); return;
        }
        game_shoot(g, DEALER, PLAYER);
    } else if (known_live == 0) {
        game_shoot(g, DEALER, DEALER);
    } else {
        /* chute com probabilidade */
        if (g->live_left * 2 > remaining) game_shoot(g, DEALER, PLAYER);
        else                              game_shoot(g, DEALER, DEALER);
    }
}
