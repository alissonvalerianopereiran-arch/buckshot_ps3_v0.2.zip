/* Buckshot Roulette (recriacao nao oficial) - PS3 / PSL1GHT - v0.2
 * Renderiza direto no framebuffer (sem shaders), fonte 5x7 embutida. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <time.h>
#include <ctype.h>

#include <ppu-lv2.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>
#include <io/pad.h>

#include "game.h"
#include "sfx.h"
#include "audio_ps3.h"

SYS_PROCESS_PARAM(1001, 0x100000);

#define CB_SIZE    0x100000
#define HOST_SIZE  (32 * 1024 * 1024)

/* ---------------- video ---------------- */

typedef struct { u32 *ptr; u32 offset; } Buffer;

static gcmContextData *ctx;
static Buffer   bufs[2];
static int      cur = 0, first_flip = 1;
static u16      W, H;
static volatile int running = 1;

static void on_sysutil(u64 status, u64 param, void *usrdata)
{
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

static void wait_flip(void)
{
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static void flip(int id)
{
    if (!first_flip) wait_flip(); else gcmResetFlipStatus();
    gcmSetFlip(ctx, id);
    rsxFlushBuffer(ctx);
    gcmSetWaitFlip(ctx);
    first_flip = 0;
}

static void video_init(void)
{
    void *host = memalign(1024 * 1024, HOST_SIZE);
    videoState st;
    videoConfiguration vc;
    videoResolution res;
    u32 pitch, size;
    int i;

    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);

    videoGetState(0, 0, &st);
    videoGetResolution(st.displayMode.resolution, &res);
    W = res.width; H = res.height;

    memset(&vc, 0, sizeof vc);
    vc.resolution = st.displayMode.resolution;
    vc.format     = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch      = W * sizeof(u32);
    videoConfigure(0, &vc, NULL, 0);
    videoGetState(0, 0, &st);

    gcmSetFlipMode(GCM_FLIP_VSYNC);

    pitch = W * sizeof(u32);
    size  = pitch * H;
    for (i = 0; i < 2; i++) {
        bufs[i].ptr = (u32 *)rsxMemalign(64, size);
        rsxAddressToOffset(bufs[i].ptr, &bufs[i].offset);
        gcmSetDisplayBuffer(i, bufs[i].offset, pitch, W, H);
    }
    gcmResetFlipStatus();
    flip(1);
}

/* ---------------- desenho ---------------- */

#define COL_BG     0x00100808
#define COL_PANEL  0x00281414
#define COL_TEXT   0x00E8D8C8
#define COL_DIM    0x00907868
#define COL_RED    0x00D03030
#define COL_GREEN  0x0040C060
#define COL_GOLD   0x00E0B040

static u32 *fb;

static void rect(int x, int y, int w, int h, u32 c)
{
    int i, j;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > W) w = W - x;
    if (y + h > H) h = H - y;
    for (j = 0; j < h; j++) {
        u32 *row = fb + (y + j) * W + x;
        for (i = 0; i < w; i++) row[i] = c;
    }
}

/* fonte 5x7, colunas, ASCII maiusculo */
static const unsigned char F57[][5] = {
 {0,0,0,0,0},          /* ' ' */
 {0x00,0x00,0x5F,0x00,0x00}, /* ! */
 {0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},
 {0x23,0x13,0x08,0x64,0x62}, /* % */
 {0,0,0,0,0},
 {0x00,0x05,0x03,0x00,0x00}, /* ' */
 {0x00,0x1C,0x22,0x41,0x00}, /* ( */
 {0x00,0x41,0x22,0x1C,0x00}, /* ) */
 {0,0,0,0,0},
 {0x08,0x08,0x3E,0x08,0x08}, /* + */
 {0x00,0x80,0x60,0x00,0x00}, /* , */
 {0x08,0x08,0x08,0x08,0x08}, /* - */
 {0x00,0x60,0x60,0x00,0x00}, /* . */
 {0x20,0x10,0x08,0x04,0x02}, /* / */
 {0x3E,0x51,0x49,0x45,0x3E}, /* 0 */
 {0x00,0x42,0x7F,0x40,0x00}, /* 1 */
 {0x42,0x61,0x51,0x49,0x46}, /* 2 */
 {0x21,0x41,0x45,0x4B,0x31}, /* 3 */
 {0x18,0x14,0x12,0x7F,0x10}, /* 4 */
 {0x27,0x45,0x45,0x45,0x39}, /* 5 */
 {0x3C,0x4A,0x49,0x49,0x30}, /* 6 */
 {0x01,0x71,0x09,0x05,0x03}, /* 7 */
 {0x36,0x49,0x49,0x49,0x36}, /* 8 */
 {0x06,0x49,0x49,0x29,0x1E}, /* 9 */
 {0x00,0x36,0x36,0x00,0x00}, /* : */
 {0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},
 {0x00,0x41,0x22,0x14,0x08}, /* > (usado no lugar de '>') */
 {0x02,0x01,0x51,0x09,0x06}, /* ? */
 {0,0,0,0,0},                /* @ */
 {0x7E,0x11,0x11,0x11,0x7E}, /* A */
 {0x7F,0x49,0x49,0x49,0x36}, /* B */
 {0x3E,0x41,0x41,0x41,0x22}, /* C */
 {0x7F,0x41,0x41,0x22,0x1C}, /* D */
 {0x7F,0x49,0x49,0x49,0x41}, /* E */
 {0x7F,0x09,0x09,0x09,0x01}, /* F */
 {0x3E,0x41,0x49,0x49,0x7A}, /* G */
 {0x7F,0x08,0x08,0x08,0x7F}, /* H */
 {0x00,0x41,0x7F,0x41,0x00}, /* I */
 {0x20,0x40,0x41,0x3F,0x01}, /* J */
 {0x7F,0x08,0x14,0x22,0x41}, /* K */
 {0x7F,0x40,0x40,0x40,0x40}, /* L */
 {0x7F,0x02,0x0C,0x02,0x7F}, /* M */
 {0x7F,0x04,0x08,0x10,0x7F}, /* N */
 {0x3E,0x41,0x41,0x41,0x3E}, /* O */
 {0x7F,0x09,0x09,0x09,0x06}, /* P */
 {0x3E,0x41,0x51,0x21,0x5E}, /* Q */
 {0x7F,0x09,0x19,0x29,0x46}, /* R */
 {0x46,0x49,0x49,0x49,0x31}, /* S */
 {0x01,0x01,0x7F,0x01,0x01}, /* T */
 {0x3F,0x40,0x40,0x40,0x3F}, /* U */
 {0x1F,0x20,0x40,0x20,0x1F}, /* V */
 {0x3F,0x40,0x38,0x40,0x3F}, /* W */
 {0x63,0x14,0x08,0x14,0x63}, /* X */
 {0x07,0x08,0x70,0x08,0x07}, /* Y */
 {0x61,0x51,0x49,0x45,0x43}, /* Z */
};

static void text(int x, int y, int sc, u32 col, const char *s)
{
    int i, cx, cy;
    for (; *s; s++, x += 6 * sc) {
        int c = toupper((unsigned char)*s);
        const unsigned char *g;
        if (c < 32 || c > 'Z') continue;
        g = F57[c - 32];
        for (cx = 0; cx < 5; cx++)
            for (cy = 0; cy < 7; cy++)
                if (g[cx] & (1 << cy))
                    rect(x + cx * sc, y + cy * sc, sc, sc, col);
        (void)i;
    }
}

static void hearts(int x, int y, int hp, int maxhp, u32 col)
{
    int i;
    for (i = 0; i < maxhp; i++)
        rect(x + i * 34, y, 28, 28, i < hp ? col : 0x00382020);
}

/* ---------------- entrada ---------------- */

/* Mapeamento (edite aqui se quiser trocar):
 *   R2 = atirar no dealer      L2 = atirar em si
 *   TRIANGULO = modo itens (dentro dele: L2/R2 trocam, X ou TRIANGULO usa, O volta)
 *   X = confirmar              START = reiniciar (pede confirmacao) */
enum { K_R2, K_L2, K_TRI, K_CIR, K_X, K_START, K_COUNT };
static int held[K_COUNT], pressed[K_COUNT];

static void read_pad(void)
{
    padInfo info;
    padData d;
    int now[K_COUNT] = {0}, i, k;

    ioPadGetInfo(&info);
    for (i = 0; i < MAX_PADS; i++) {
        if (!info.status[i]) continue;
        ioPadGetData(i, &d);
        if (d.BTN_R2)       now[K_R2] = 1;
        if (d.BTN_L2)       now[K_L2] = 1;
        if (d.BTN_TRIANGLE) now[K_TRI] = 1;
        if (d.BTN_CIRCLE)   now[K_CIR] = 1;
        if (d.BTN_CROSS)    now[K_X] = 1;
        if (d.BTN_START)    now[K_START] = 1;
    }
    for (k = 0; k < K_COUNT; k++) {
        pressed[k] = now[k] && !held[k];
        held[k] = now[k];
    }
}

/* ---------------- som: eventos -> sfx ---------------- */

#define DELAY_NEXT 0.55f   /* pump/recarga entram depois do tiro */

static void drain_events(Game *g)
{
    int i;
    for (i = 0; i < g->ev_n; i++) {
        int e = g->ev[i];
        switch (e) {
        case EV_BLAST:  sfx_play(SFX_BLAST, 1.0f, 0.0f); break;
        case EV_BLANK:  sfx_play(SFX_BLANK, 0.9f, 0.0f); break;
        case EV_RACK:   sfx_play(SFX_RACK, 0.8f, DELAY_NEXT); break;
        case EV_RELOAD: sfx_play(SFX_RELOAD, 0.8f, DELAY_NEXT); break;
        case EV_HURT:   sfx_play(SFX_HURT, 0.8f, 0.03f); break;
        case EV_ROUND:  sfx_play(SFX_ROUND, 0.8f, 0.0f); break;
        case EV_WIN:    sfx_play(SFX_WIN, 0.8f, 0.6f); break;
        case EV_LOSE:   sfx_play(SFX_LOSE, 0.8f, 0.6f); break;
        case EV_ITEM_BASE + ITEM_LUPA:    sfx_play(SFX_LUPA, 0.8f, 0.0f); break;
        case EV_ITEM_BASE + ITEM_CERVEJA: sfx_play(SFX_BEER, 0.8f, 0.0f); break;
        case EV_ITEM_BASE + ITEM_CIGARRO: sfx_play(SFX_CIGARRO, 0.8f, 0.0f); break;
        case EV_ITEM_BASE + ITEM_SERRA:   sfx_play(SFX_SERRA, 0.8f, 0.0f); break;
        case EV_ITEM_BASE + ITEM_ALGEMAS: sfx_play(SFX_ALGEMAS, 0.8f, 0.0f); break;
        default: break;
        }
    }
    g->ev_n = 0;
}

/* ---------------- itens ---------------- */

static const char *item_desc(int it)
{
    switch (it) {
    case ITEM_LUPA:    return "VE SE O CARTUCHO ATUAL E REAL OU VAZIO";
    case ITEM_CERVEJA: return "EJETA O CARTUCHO ATUAL";
    case ITEM_CIGARRO: return "RECUPERA 1 DE VIDA";
    case ITEM_SERRA:   return "PROXIMO TIRO REAL CAUSA 2 DE DANO";
    case ITEM_ALGEMAS: return "O DEALER PERDE A PROXIMA VEZ";
    default:           return "";
    }
}

static int count_items(Game *g)
{
    int i, n = 0;
    for (i = 0; i < MAX_ITEMS; i++) if (g->items[PLAYER][i]) n++;
    return n;
}

/* proximo slot ocupado a partir de 'cur' na direcao dir (+1/-1); -1 se nao ha itens */
static int next_item(Game *g, int cur, int dir)
{
    int k, i = cur;
    for (k = 0; k < MAX_ITEMS; k++) {
        i = (i + dir + MAX_ITEMS) % MAX_ITEMS;
        if (g->items[PLAYER][i]) return i;
    }
    return -1;
}

/* ---------------- telas ---------------- */

enum { SCR_TITLE, SCR_GAME, SCR_CONFIRM };

static void draw_game(Game *g, int item_mode, int isel)
{
    int i, y, sc = (W >= 1280) ? 3 : 2, lh = 10 * sc;
    char buf[96];
    int mx = W / 20, top = H / 18;

    rect(0, 0, W, H, COL_BG);

    snprintf(buf, sizeof buf, "RODADA %d / 3", g->round);
    text(mx, top, sc + 1, COL_GOLD, buf);
    snprintf(buf, sizeof buf, "RESTAM: %d REAIS  %d VAZIOS", g->live_left, g->blank_left);
    text(mx, top + 12 * sc, sc, COL_TEXT, buf);

    text(mx, top + 26 * sc, sc, COL_TEXT, "DEALER");
    hearts(mx + 100 * sc / 2, top + 25 * sc, g->hp[DEALER], g->maxhp, COL_RED);
    text(mx, top + 38 * sc, sc, COL_TEXT, "VOCE");
    hearts(mx + 100 * sc / 2, top + 37 * sc, g->hp[PLAYER], g->maxhp, COL_GREEN);

    y = top + 50 * sc;
    if (g->sawed)          { text(mx, y, sc, COL_RED,  "CANO SERRADO: DANO 2"); y += lh; }
    if (g->cuffed[DEALER]) { text(mx, y, sc, COL_GOLD, "DEALER ALGEMADO");      y += lh; }
    if (g->cuffed[PLAYER]) { text(mx, y, sc, COL_GOLD, "VOCE ALGEMADO");        y += lh; }
    if (g->peek >= 0)      { text(mx, y, sc, COL_GOLD, g->peek ? "CARTUCHO ATUAL: REAL" : "CARTUCHO ATUAL: VAZIO"); }

    text(W / 2, top, sc, COL_DIM, "ITENS DO DEALER");
    for (i = 0, y = top + lh; i < MAX_ITEMS; i++)
        if (g->items[DEALER][i]) { text(W / 2, y, sc, COL_TEXT, item_name(g->items[DEALER][i])); y += lh; }

    rect(mx - 8, H / 2 - 8, W - 2 * mx + 16, LOG_LINES * lh + 16, COL_PANEL);
    for (i = 0; i < g->log_n; i++)
        text(mx, H / 2 + i * lh, sc, COL_TEXT, g->log[i]);

    y = H / 2 + LOG_LINES * lh + 2 * lh;

    if (g->state != GS_PLAYING) {
        text(mx, y, sc + 1, g->state == GS_WIN ? COL_GREEN : COL_RED,
             g->state == GS_WIN ? "VITORIA!" : "VOCE MORREU.");
        text(mx, y + 14 * sc, sc, COL_TEXT, "X: VOLTAR AO MENU   START: REINICIAR");
        return;
    }
    if (g->turn == DEALER) {
        text(mx, y, sc, COL_DIM, "VEZ DO DEALER...");
        return;
    }

    /* mesa de itens do jogador */
    text(mx, y, sc, COL_DIM, "SUA MESA:");
    {
        int x = mx + 11 * 6 * sc;
        for (i = 0; i < MAX_ITEMS; i++) {
            const char *nm;
            int w;
            if (!g->items[PLAYER][i]) continue;
            nm = item_name(g->items[PLAYER][i]);
            w = (int)strlen(nm) * 6 * sc;
            if (item_mode && i == isel) rect(x - 6, y - 5, w + 12, lh + 4, 0x00604818);
            text(x, y, sc, (item_mode && i == isel) ? COL_GOLD : COL_TEXT, nm);
            x += w + 20 * sc;
        }
        if (count_items(g) == 0) text(x, y, sc, COL_DIM, "(VAZIA)");
    }

    if (item_mode) {
        text(mx, y + 2 * lh, sc, COL_GOLD, item_desc(g->items[PLAYER][isel]));
        text(mx, y + 4 * lh, sc, COL_DIM, "L2/R2: TROCAR   X: USAR   O: VOLTAR");
    } else {
        text(mx, y + 2 * lh, sc, COL_TEXT, "R2: ATIRAR NO DEALER");
        text(mx, y + 3 * lh, sc, COL_TEXT, "L2: ATIRAR EM SI");
        text(mx, y + 4 * lh, sc, COL_TEXT, "TRIANGULO: ITENS");
        text(mx, y + 5 * lh, sc, COL_DIM,  "START: REINICIAR");
    }
}

static void draw_title(void)
{
    int sc = (W >= 1280) ? 6 : 4;
    rect(0, 0, W, H, COL_BG);
    text(W / 2 - 6 * 8 * sc / 2, H / 3, sc, COL_RED, "BUCKSHOT");
    text(W / 2 - 6 * 8 * sc / 2, H / 3 + 10 * sc, sc, COL_TEXT, "ROULETTE");
    text(W / 2 - 150, H / 2 + 60, 2, COL_DIM, "PS3 - RECRIACAO NAO OFICIAL - V0.2");
    text(W / 2 - 90, H / 2 + 110, 2, COL_GOLD, "APERTE X PARA COMECAR");
}

static void draw_confirm(void)
{
    int sc = (W >= 1280) ? 4 : 3;
    rect(0, 0, W, H, COL_BG);
    text(W / 2 - 5 * 6 * sc, H / 3, sc, COL_GOLD, "REINICIAR?");
    text(W / 2 - 170, H / 2, 2, COL_TEXT, "X: SIM (VOLTA AO MENU)");
    text(W / 2 - 170, H / 2 + 30, 2, COL_DIM, "O: CANCELAR");
}

int main(void)
{
    Game g;
    int screen = SCR_TITLE;
    int item_mode = 0, isel = 0;
    int dealer_wait = 0;
    uint32_t frames = 0;

    sysUtilRegisterCallback(0, on_sysutil, NULL);
    video_init();
    ioPadInit(7);
    memset(&g, 0, sizeof g);

    sfx_init();
    if (audio_init()) sfx_start_ambience(0.10f);

    while (running) {
        sysUtilCheckCallback();
        frames++;
        read_pad();
        fb = bufs[cur].ptr;

        if (screen == SCR_TITLE) {
            if (pressed[K_X]) {
                game_init(&g, (uint32_t)time(NULL) ^ (frames * 2654435761u));
                screen = SCR_GAME; item_mode = 0; dealer_wait = 0;
                sfx_play(SFX_SELECT, 1.0f, 0.0f);
            }
            draw_title();

        } else if (screen == SCR_CONFIRM) {
            if (pressed[K_X])        { screen = SCR_TITLE; sfx_play(SFX_SELECT, 1.0f, 0.0f); }
            else if (pressed[K_CIR] || pressed[K_START]) { screen = SCR_GAME; sfx_play(SFX_BACK, 1.0f, 0.0f); }
            draw_confirm();

        } else { /* SCR_GAME */
            if (pressed[K_START]) {
                screen = SCR_CONFIRM; item_mode = 0;
                sfx_play(SFX_SELECT, 1.0f, 0.0f);
            } else if (g.state != GS_PLAYING) {
                if (pressed[K_X]) screen = SCR_TITLE;
            } else if (g.turn == PLAYER) {
                if (item_mode) {
                    if (count_items(&g) == 0) item_mode = 0;
                    if (pressed[K_R2]) { int n = next_item(&g, isel, +1); if (n >= 0) isel = n; sfx_play(SFX_TICK, 1.0f, 0.0f); }
                    if (pressed[K_L2]) { int n = next_item(&g, isel, -1); if (n >= 0) isel = n; sfx_play(SFX_TICK, 1.0f, 0.0f); }
                    if (pressed[K_X] || pressed[K_TRI]) {
                        game_use_item(&g, PLAYER, isel);
                        item_mode = 0;
                    } else if (pressed[K_CIR]) {
                        item_mode = 0; sfx_play(SFX_BACK, 1.0f, 0.0f);
                    }
                } else {
                    if (pressed[K_R2]) {
                        game_shoot(&g, PLAYER, DEALER);
                        dealer_wait = 90;
                    } else if (pressed[K_L2]) {
                        game_shoot(&g, PLAYER, PLAYER);
                        dealer_wait = 90;
                    } else if (pressed[K_TRI]) {
                        int n = next_item(&g, MAX_ITEMS - 1, +1);   /* primeiro item */
                        if (n >= 0) { item_mode = 1; isel = n; sfx_play(SFX_SELECT, 1.0f, 0.0f); }
                        else sfx_play(SFX_BACK, 1.0f, 0.0f);
                    }
                }
            } else {
                item_mode = 0;
                if (dealer_wait > 0) dealer_wait--;
                else { dealer_act(&g); dealer_wait = 90; }   /* ~1,5 s por acao */
            }
            draw_game(&g, item_mode, isel);
        }

        drain_events(&g);
        audio_pump();

        flip(cur);
        cur ^= 1;
    }

    audio_shutdown();
    ioPadEnd();
    gcmSetWaitFlip(ctx);
    rsxFinish(ctx, 1);
    return 0;
}
