#include "sfx.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define PI 3.14159265358979f
#define R  ((float)SFX_RATE)

static unsigned int ns = 12345u;
static float rnd(void)
{
    ns = ns * 1664525u + 1013904223u;
    return (float)((ns >> 8) & 0xFFFF) / 32768.0f - 1.0f;
}

static short *pcm[SFX_COUNT];
static int    plen[SFX_COUNT];
static short *amb_pcm;
static int    amb_len;

static const char *NAMES[SFX_COUNT] = {
    "blast", "blank", "rack", "reload", "hurt", "lupa", "beer", "cigarro",
    "serra", "algemas", "tick", "select", "back", "round", "win", "lose"
};
const char *sfx_name(int id) { return NAMES[id]; }

/* ---------- ferramentas de sintese ---------- */

static float *fnew(int n) { return (float *)calloc((size_t)n, sizeof(float)); }
static int secs(float s)  { return (int)(s * R); }

static void lowpass(float *b, int n, float a)
{
    float y = 0.0f; int i;
    for (i = 0; i < n; i++) { y += a * (b[i] - y); b[i] = y; }
}

static void highpass(float *b, int n, float a)
{
    float y = 0.0f; int i;
    for (i = 0; i < n; i++) { y += a * (b[i] - y); b[i] = b[i] - y; }
}

/* estalo metalico: ruido + senoide ressonante, decaimento exponencial */
static void click(float *b, int n, float t0, float amp, float freq, float decay)
{
    int at = secs(t0), m = secs(0.18f), i;
    for (i = 0; i < m && at + i < n; i++) {
        float t = (float)i / R;
        b[at + i] += amp * expf(-t * decay) *
                     (0.55f * sinf(2.0f * PI * freq * t) + 0.45f * rnd());
    }
}

static void tone(float *b, int n, float t0, float amp, float freq, float decay, float dur)
{
    int at = secs(t0), m = secs(dur), i;
    for (i = 0; i < m && at + i < n; i++) {
        float t = (float)i / R;
        b[at + i] += amp * expf(-t * decay) * sinf(2.0f * PI * freq * t);
    }
}

/* eco de sala: 3 filtros comb */
static void reverb(float *b, int n, float mix, float fb)
{
    static const int d[3] = { 1427, 1781, 1973 };
    float *out = fnew(n), *c = fnew(n);
    int k, i;
    for (k = 0; k < 3; k++) {
        for (i = 0; i < n; i++)
            c[i] = b[i] + ((i >= d[k]) ? fb * c[i - d[k]] : 0.0f);
        for (i = 0; i < n; i++) out[i] += c[i] * (1.0f / 3.0f);
    }
    for (i = 0; i < n; i++) b[i] += mix * out[i];
    free(out); free(c);
}

static short *to_pcm(float *b, int n, float peak)
{
    float mx = 1e-6f, g; int i;
    short *o = (short *)malloc((size_t)n * sizeof(short));
    for (i = 0; i < n; i++) { float a = fabsf(b[i]); if (a > mx) mx = a; }
    g = peak / mx;
    for (i = 0; i < n; i++) {
        float v = b[i] * g;
        if (i > n - 240) v *= (float)(n - i) / 240.0f;   /* fade-out: evita estalo no fim */
        if (v > 1.0f)  v = 1.0f;
        if (v < -1.0f) v = -1.0f;
        o[i] = (short)(v * 32767.0f);
    }
    free(b);
    return o;
}

static void store(int id, float *b, int n, float peak)
{
    pcm[id] = to_pcm(b, n, peak);
    plen[id] = n;
}

/* ---------- os sons ---------- */

static void mk_blast(void)       /* tiro real: estalo + estrondo grave + eco de sala */
{
    int n = secs(1.8f), i;
    float *b = fnew(n), *r = fnew(n), *l = fnew(n);
    for (i = 0; i < n; i++) { r[i] = rnd(); l[i] = r[i]; }
    lowpass(l, n, 0.06f);
    for (i = 0; i < n; i++) {
        float t = (float)i / R;
        b[i] = r[i] * expf(-t * 45.0f)
             + l[i] * expf(-t * 5.5f) * 6.0f
             + sinf(2.0f * PI * 50.0f * t) * expf(-t * 7.0f) * 1.2f;
    }
    free(r); free(l);
    reverb(b, n, 0.9f, 0.55f);
    store(SFX_BLAST, b, n, 0.95f);
}

static void mk_blank(void)       /* tiro vazio: clique seco do gatilho */
{
    int n = secs(0.25f);
    float *b = fnew(n);
    click(b, n, 0.000f, 1.0f, 1800.0f, 90.0f);
    click(b, n, 0.012f, 0.4f,  700.0f, 60.0f);
    store(SFX_BLANK, b, n, 0.8f);
}

static void mk_rack(void)        /* "chk-chak" da pump */
{
    int n = secs(0.45f), i;
    float *b = fnew(n), *s = fnew(n);
    for (i = 0; i < secs(0.14f); i++) s[i] = rnd() * 0.25f;   /* deslize */
    lowpass(s, n, 0.25f);
    for (i = 0; i < n; i++) b[i] = s[i];
    free(s);
    click(b, n, 0.000f, 0.8f,  600.0f, 50.0f);
    click(b, n, 0.170f, 1.0f, 1100.0f, 60.0f);
    store(SFX_RACK, b, n, 0.85f);
}

static void mk_reload(void)      /* cartuchos entrando + pump */
{
    int n = secs(1.0f);
    float *b = fnew(n);
    click(b, n, 0.00f, 0.7f, 1400.0f, 70.0f);
    click(b, n, 0.13f, 0.7f, 1550.0f, 70.0f);
    click(b, n, 0.27f, 0.7f, 1650.0f, 70.0f);
    click(b, n, 0.40f, 0.7f, 1500.0f, 70.0f);
    tone (b, n, 0.00f, 0.15f, 300.0f, 30.0f, 0.5f);
    click(b, n, 0.62f, 0.8f,  600.0f, 50.0f);
    click(b, n, 0.79f, 1.0f, 1100.0f, 60.0f);
    store(SFX_RELOAD, b, n, 0.8f);
}

static void mk_hurt(void)
{
    int n = secs(0.5f), i;
    float *b = fnew(n), *r = fnew(n);
    for (i = 0; i < n; i++) r[i] = rnd();
    lowpass(r, n, 0.1f);
    for (i = 0; i < n; i++) {
        float t = (float)i / R;
        b[i] = sinf(2.0f * PI * 70.0f * t) * expf(-t * 10.0f) + r[i] * expf(-t * 25.0f) * 3.0f;
    }
    free(r);
    store(SFX_HURT, b, n, 0.7f);
}

static void mk_lupa(void)        /* tilintar de vidro */
{
    int n = secs(0.7f);
    float *b = fnew(n);
    tone(b, n, 0.00f, 1.0f, 2600.0f, 9.0f, 0.7f);
    tone(b, n, 0.00f, 0.6f, 3900.0f, 12.0f, 0.7f);
    tone(b, n, 0.00f, 0.3f, 5200.0f, 16.0f, 0.7f);
    store(SFX_LUPA, b, n, 0.6f);
}

static void mk_beer(void)        /* abrir lata: estalo + chiado */
{
    int n = secs(1.0f), i;
    float *b = fnew(n);
    for (i = 0; i < n; i++) {
        float t = (float)i / R, env = 0.0f;
        if (t > 0.04f && t < 0.9f)
            env = (t < 0.15f ? (t - 0.04f) / 0.11f : expf(-(t - 0.15f) * 3.0f));
        b[i] = rnd() * env * 0.8f;
    }
    highpass(b, n, 0.35f);
    click(b, n, 0.00f, 1.0f, 800.0f, 60.0f);
    store(SFX_BEER, b, n, 0.7f);
}

static void mk_cigarro(void)     /* isqueiro + crepitar + tragada */
{
    int n = secs(1.3f), i;
    float *b = fnew(n), *c = fnew(n);
    click(b, n, 0.00f, 0.9f, 2200.0f, 80.0f);
    click(b, n, 0.09f, 1.0f, 2600.0f, 80.0f);
    for (i = secs(0.2f); i < secs(0.9f); i++)
        if (rnd() > 0.985f) c[i] = rnd() * 0.9f;                 /* estalinhos */
    highpass(c, n, 0.5f);
    for (i = 0; i < n; i++) b[i] += c[i];
    for (i = 0; i < n; i++) c[i] = rnd();
    lowpass(c, n, 0.08f);
    for (i = secs(0.3f); i < secs(1.2f); i++) {
        float t = (float)(i - secs(0.3f)) / R;
        b[i] += c[i] * 2.5f * sinf(PI * t / 0.9f);               /* tragada suave */
    }
    free(c);
    store(SFX_CIGARRO, b, n, 0.7f);
}

static void mk_serra(void)       /* serra eletrica */
{
    int n = secs(0.9f), i;
    float *b = fnew(n);
    float ph = 0.0f;
    for (i = 0; i < n; i++) {
        float t = (float)i / R;
        float f = 80.0f + 40.0f * sinf(2.0f * PI * 3.0f * t);
        float env = (t < 0.05f ? t / 0.05f : (t > 0.75f ? (0.9f - t) / 0.15f : 1.0f));
        float saw, am = 1.0f + 0.4f * sinf(2.0f * PI * 28.0f * t);
        ph += f / R; ph -= floorf(ph);
        saw = 2.0f * ph - 1.0f;
        b[i] = (saw * 0.8f + rnd() * 0.35f) * am * env;
    }
    lowpass(b, n, 0.35f);
    store(SFX_SERRA, b, n, 0.7f);
}

static void mk_algemas(void)     /* clinks metalicos */
{
    int n = secs(0.7f);
    float *b = fnew(n);
    tone (b, n, 0.00f, 1.0f, 3100.0f, 25.0f, 0.4f);
    tone (b, n, 0.00f, 0.5f, 4700.0f, 30.0f, 0.4f);
    click(b, n, 0.00f, 0.5f, 3000.0f, 90.0f);
    tone (b, n, 0.10f, 0.9f, 2300.0f, 22.0f, 0.4f);
    click(b, n, 0.10f, 0.5f, 2500.0f, 90.0f);
    tone (b, n, 0.22f, 0.7f, 3600.0f, 28.0f, 0.4f);
    store(SFX_ALGEMAS, b, n, 0.65f);
}

static void mk_ui(void)
{
    int n = secs(0.05f); float *b = fnew(n);
    tone(b, n, 0.0f, 1.0f, 1200.0f, 70.0f, 0.05f);
    store(SFX_TICK, b, n, 0.35f);

    n = secs(0.12f); b = fnew(n);
    tone(b, n, 0.00f, 1.0f,  700.0f, 30.0f, 0.12f);
    tone(b, n, 0.04f, 1.0f, 1050.0f, 30.0f, 0.08f);
    store(SFX_SELECT, b, n, 0.4f);

    n = secs(0.09f); b = fnew(n);
    tone(b, n, 0.0f, 1.0f, 500.0f, 40.0f, 0.09f);
    store(SFX_BACK, b, n, 0.35f);
}

static void mk_stingers(void)
{
    int n = secs(1.4f), i;
    float *b = fnew(n);
    /* inicio de rodada: pancada grave + subida sombria */
    for (i = 0; i < n; i++) {
        float t = (float)i / R;
        b[i] = sinf(2.0f * PI * 45.0f * t) * expf(-t * 2.5f)
             + 0.5f * sinf(2.0f * PI * 67.5f * t) * expf(-t * 3.0f);
    }
    store(SFX_ROUND, b, n, 0.6f);

    n = secs(1.8f); b = fnew(n);
    tone(b, n, 0.00f, 1.0f, 220.0f, 1.6f, 1.8f);
    tone(b, n, 0.10f, 0.8f, 277.2f, 1.6f, 1.7f);
    tone(b, n, 0.20f, 0.8f, 329.6f, 1.6f, 1.6f);
    store(SFX_WIN, b, n, 0.5f);

    n = secs(1.8f); b = fnew(n);
    {
        float ph = 0.0f;
        for (i = 0; i < n; i++) {
            float t = (float)i / R, f = 220.0f * expf(-t * 0.5f);
            ph += f / R;
            b[i] = sinf(2.0f * PI * ph) * expf(-t * 1.2f);
        }
    }
    store(SFX_LOSE, b, n, 0.55f);
}

static void mk_ambience(void)    /* zumbido grave em loop perfeito (2 s) */
{
    int n = secs(2.0f), i;
    float *b = fnew(n);
    for (i = 0; i < n; i++) {
        float t = (float)i / R;
        b[i] = 0.5f * sinf(2.0f * PI * 55.0f * t)
             + 0.3f * sinf(2.0f * PI * 110.0f * t) * (1.0f + 0.3f * sinf(2.0f * PI * 0.5f * t))
             + 0.1f * sinf(2.0f * PI * 165.0f * t);
    }
    /* sem fade-out aqui: precisa fechar o loop sem emenda */
    {
        short *o = (short *)malloc((size_t)n * sizeof(short));
        for (i = 0; i < n; i++) o[i] = (short)(b[i] * 0.9f * 32767.0f / 0.95f);
        amb_pcm = o; amb_len = n;
    }
    free(b);
}

void sfx_init(void)
{
    mk_blast(); mk_blank(); mk_rack(); mk_reload(); mk_hurt();
    mk_lupa(); mk_beer(); mk_cigarro(); mk_serra(); mk_algemas();
    mk_ui(); mk_stingers(); mk_ambience();
}

const short *sfx_data(int id, int *n)
{
    if (n) *n = plen[id];
    return pcm[id];
}

/* ---------- mixer ---------- */

#define NVOICES 16
typedef struct {
    const short *d; int n, pos, delay, loop, active;
    float vol;
} Voice;
static Voice vox[NVOICES];

void sfx_play(int id, float vol, float delay_sec)
{
    int i;
    if (!pcm[id]) return;
    for (i = 1; i < NVOICES; i++)           /* voz 0 reservada p/ ambiente */
        if (!vox[i].active) {
            vox[i].d = pcm[id]; vox[i].n = plen[id]; vox[i].pos = 0;
            vox[i].delay = (int)(delay_sec * R); vox[i].loop = 0;
            vox[i].vol = vol; vox[i].active = 1;
            return;
        }
}

void sfx_start_ambience(float vol)
{
    if (!amb_pcm) return;
    vox[0].d = amb_pcm; vox[0].n = amb_len; vox[0].pos = 0; vox[0].delay = 0;
    vox[0].loop = 1; vox[0].vol = vol; vox[0].active = 1;
}

void sfx_mix(float *out, int frames)
{
    int v, i;
    memset(out, 0, (size_t)frames * 2 * sizeof(float));
    for (v = 0; v < NVOICES; v++) {
        Voice *x = &vox[v];
        if (!x->active) continue;
        for (i = 0; i < frames; i++) {
            float s;
            if (x->delay > 0) { x->delay--; continue; }
            s = (float)x->d[x->pos] * (1.0f / 32768.0f) * x->vol;
            out[2 * i]     += s;
            out[2 * i + 1] += s;
            if (++x->pos >= x->n) {
                if (x->loop) x->pos = 0;
                else { x->active = 0; break; }
            }
        }
    }
    for (i = 0; i < frames * 2; i++) {
        if (out[i] > 1.0f) out[i] = 1.0f;
        if (out[i] < -1.0f) out[i] = -1.0f;
    }
}
