/* Backend de audio do PS3 (PSL1GHT libaudio): 2 canais, 8 blocos de 256 amostras, 48 kHz.
 * Estrategia: a cada frame, preenche os blocos que o hardware ja leu.
 *
 * ATENCAO: esta e a parte mais incerta (nao testei no console). Se o som sair
 * picotado/mudo, o suspeito e a leitura do readIndex (u64 vs u32). */
#include <stdio.h>
#include <string.h>
#include <ppu-lv2.h>
#include <audio/audio.h>

#include "audio_ps3.h"
#include "sfx.h"

static audioPortConfig cfg;
static u32  port;
static u32  wr = 0;
static int  ok = 0;

int audio_init(void)
{
    audioPortParam params;

    if (audioInit() != 0) return 0;

    memset(&params, 0, sizeof params);
    params.numChannels = AUDIO_PORT_2CH;
    params.numBlocks   = AUDIO_BLOCK_8;
    params.attr        = 0;
    params.level       = 1.0f;

    if (audioPortOpen(&params, &port) != 0) return 0;
    if (audioGetPortConfig(port, &cfg) != 0) return 0;
    if (audioPortStart(port) != 0) return 0;

    wr = (u32)(*(volatile u64 *)(u64)cfg.readIndex) % 8;
    ok = 1;
    return 1;
}

void audio_pump(void)
{
    u32 rd;
    int guard = 0;
    if (!ok) return;

    rd = (u32)(*(volatile u64 *)(u64)cfg.readIndex) % 8;
    while (wr != rd && guard++ < 8) {
        float *p = (float *)((u64)cfg.audioDataStart) + wr * AUDIO_BLOCK_SAMPLES * 2;
        sfx_mix(p, AUDIO_BLOCK_SAMPLES);
        wr = (wr + 1) % 8;
    }
}

void audio_shutdown(void)
{
    if (!ok) return;
    audioPortStop(port);
    audioPortClose(port);
    audioQuit();
    ok = 0;
}
