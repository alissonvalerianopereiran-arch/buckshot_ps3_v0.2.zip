# Buckshot Roulette - PS3 v0.2 (recriacao nao oficial)

Projeto independente, reescrito do zero em C. Sem assets do jogo original
(os sons sao sintetizados por codigo). Jogo original: Mike Klubnika.

## Controles
- R2: atirar no dealer
- L2: atirar em si
- TRIANGULO: abre os itens (la dentro: L2/R2 trocam, X ou TRIANGULO usa, O volta)
- X: confirmar
- START: reiniciar (tela de confirmacao: X = sim/volta ao menu, O = cancelar)

## Sons (sintetizados, em source/sfx.c)
tiro real, clique de vazio, pump, recarga, dano, lupa, cerveja, cigarro,
serra, algemas, UI, inicio de rodada, vitoria, derrota e zumbido de fundo.
Previews em WAV no outro zip. Para editar um som, mexa na funcao mk_xxx().

## Testes no PC (sem PS3)
    gcc -std=c99 -Iinclude pc_test/main_pc.c source/game.c -o br_pc && ./br_pc
    gcc -std=c99 -Iinclude pc_test/sfx_dump.c source/sfx.c -lm -o sfx_dump && mkdir -p out && ./sfx_dump out

## Compilar pro PS3 (PSL1GHT + ps3toolchain)
    export PSL1GHT=<caminho>
    make          # buckshot_ps3.self
    make pkg      # .pkg
    make run      # envia via ps3load

## Pontos mais incertos (nao testados no console)
1. source/audio_ps3.c: leitura do readIndex (u64 vs u32). Sintoma: som picotado/mudo.
2. Nomes das funcoes de video/controle do PSL1GHT.
3. Makefile: se falhar, use o de um sample do PSL1GHT (trocar TITLE/APPID/LIBS, incluindo -laudio).
